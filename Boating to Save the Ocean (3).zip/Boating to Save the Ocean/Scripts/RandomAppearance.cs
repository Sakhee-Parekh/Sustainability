﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomAppearance : MonoBehaviour
{
    Movement move;
    // Start is called before the first frame update
    double timePassed = 0.0;
    double timetostop = 0.0;

    bool gameover = false;
    bool trashgone = false;
    bool gamestart = false;



    [SerializeField]
    private GameObject trash;
    [SerializeField]
    private GameObject GoodEnd;
    [SerializeField]
    private GameObject BadEnd;
    [SerializeField]
    private GameObject Beginning;

    void Start()
    {
        GoodEnd.SetActive(false);
        BadEnd.SetActive(false);
        Beginning.SetActive(true);
        Time.timeScale = 0;



    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            gamestart = true;
        }
        else
        {

        }
        if (gamestart == true)
        {
            Beginning.SetActive(false);
            Time.timeScale = 1;
        }
        else
        {

        }

        

        

        timePassed += Time.deltaTime;
        timetostop += Time.deltaTime;
        if (timePassed >= 3 && timetostop <= 10)
        {
            Create();
            timePassed = 0;
        }
        else if (timetostop > 20)
        {
            gameover = true;
            //run text here
            if(Object.FindObjectsOfType(typeof(Pickup)).Length > 0)
            {
                trashgone = false;
            }
            else
            {
                trashgone = true;
            }
            
            if(trashgone == true)
            {
                GoodEnd.SetActive(true);
            }
            else
            {
                BadEnd.SetActive(true);
            }

            
            Time.timeScale = 0;
        }
        else
        {

        }
   
    }

    


    void Create()
    {
        Vector2 spawn = new Vector2(Random.Range(-22f, 22f), Random.Range(-9f, 9f));
        Instantiate(trash, spawn, trash.transform.rotation);
    }


}
